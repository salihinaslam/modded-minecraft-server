#version 120
#extension GL_ARB_shader_texture_lod : enable
/* MakeUp - composite1.fsh
Render: Antialiasing and motion blur

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define COMPOSITE2_SHADER

#include "/common/composite2_vertex.glsl"
